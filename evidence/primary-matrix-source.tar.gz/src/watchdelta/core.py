from __future__ import annotations
import hashlib, json, os, shutil, subprocess, sys
from pathlib import Path
from typing import Any
TOKEN0 = 'WD0000000000'

def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def projection(folder: Path, extension: str) -> dict[str, str]:
    """Identity-normalized, path-sensitive byte hashes; no source token stripping."""
    if not folder.exists(): return {}
    answer = {}
    for p in sorted(folder.rglob('*' + extension)):
        if p.is_symlink(): raise ValueError('Symlink outside the declared small-tree contract')
        if p.is_file():
            try: answer[p.relative_to(folder).as_posix()] = digest(p.read_bytes())
            except FileNotFoundError: continue
    return answer

def source_files(root: Path, tool: str) -> list[Path]:
    ext = '.ts' if tool == 'tsc' else '.md'
    return sorted(p for p in (root / 'src').rglob('*' + ext)
                  if p.is_file() and not any(x.startswith('.') for x in p.relative_to(root/'src').parts))

def source_fingerprint(root: Path, tool: str) -> tuple[str, int]:
    h = hashlib.sha256(); total = 0
    for p in source_files(root, tool):
        if p.is_symlink(): raise ValueError('Symlinks not supported')
        data = p.read_bytes(); name = p.relative_to(root).as_posix().encode()
        h.update(len(name).to_bytes(8, 'big')); h.update(name)
        h.update(len(data).to_bytes(8, 'big')); h.update(data); total += len(data)
    return h.hexdigest(), total

def tsc_path() -> str:
    candidate = os.environ.get('WATCHDELTA_TSC') or shutil.which('tsc')
    if not candidate: raise RuntimeError('TypeScript 5.8.3 is required; set WATCHDELTA_TSC')
    return candidate

def create_fixture(root: Path, tool: str, mode: str) -> None:
    (root / 'src').mkdir(parents=True)
    if tool == 'tsc':
        (root/'src/message.ts').write_text(f'export const message = "{TOKEN0}";\n')
        (root/'src/index.ts').write_text('import { message } from "./message";\nconsole.log(JSON.stringify({message}));\n')
        cfg: dict[str, Any] = {'compilerOptions': {'target':'ES2020', 'module':'CommonJS', 'strict':True,
                'rootDir':'src','outDir':'out','skipLibCheck':True,'types':[], 'noEmitOnError':True},
                'include':['src/**/*.ts']}
        if mode == 'recommended':
            cfg['watchOptions'] = {'watchFile':'useFsEvents','watchDirectory':'useFsEvents', 'fallbackPolling':'dynamicPriority'}
        elif mode == 'poll':
            cfg['watchOptions'] = {'watchFile':'fixedPollingInterval','watchDirectory':'fixedPollingInterval'}
        elif mode == 'wrong_filter': cfg['watchOptions'] = {'excludeFiles':['./src/message.ts']}
        (root/'tsconfig.json').write_text(json.dumps(cfg,indent=2)+'\n')
    else:
        (root/'src/index.md').write_text('# Development guide\n\n'+TOKEN0+'\n\nA **small** documentation fixture.\n')
    (root/'out').mkdir()

def build_docs(root: Path) -> dict[str, int]:
    """Real markdown-it-py rendering; no synthetic event emitter or fake build."""
    from markdown_it import MarkdownIt
    renderer = MarkdownIt('commonmark', {'html':False}); count, total = 0, 0
    for p in source_files(root, 'docs'):
        data = p.read_bytes(); total += len(data)
        target = root/'out'/p.relative_to(root/'src').with_suffix('.html')
        target.parent.mkdir(parents=True,exist_ok=True)
        rendered = '<!doctype html>\n<meta charset="utf-8">\n' + renderer.render(data.decode('utf-8'))
        stage = target.with_suffix('.html.wd-stage')
        stage.write_text(rendered,encoding='utf-8'); os.replace(stage,target); count += 1
    return {'source_bytes':total,'source_files':count}

def build_once(root: Path, tool: str) -> subprocess.CompletedProcess[str] | dict[str, int]:
    if tool == 'docs': return build_docs(root)
    return subprocess.run([tsc_path(),'--project',str(root/'tsconfig.json'),'--pretty','false'],
                          cwd=root,text=True,capture_output=True,timeout=30)

def clean_build(root: Path, tool: str, dest: Path) -> dict[str, Any]:
    """Fresh output dir/process using identical, hashed final source tree."""
    before = source_fingerprint(root,tool)[0]; shutil.copytree(root/'src',dest/'src')
    if tool == 'tsc': shutil.copy2(root/'tsconfig.json',dest/'tsconfig.json')
    cmd = [sys.executable,'-m','watchdelta.build','--root',str(dest),'--tool',tool]
    result = subprocess.run(cmd,capture_output=True,text=True,timeout=35)
    after = source_fingerprint(root,tool)[0]
    if before != after or source_fingerprint(dest,tool)[0] != before:
        raise RuntimeError('Final source tree changed across clean-build boundary')
    return {'returncode':result.returncode,'stdout':result.stdout,'stderr':result.stderr,
            'source_sha256':before,'projection':projection(dest/'out','.js' if tool=='tsc' else '.html'),
            'command':[sys.executable,'-m','watchdelta.build','--root','<clean>','--tool',tool]}

def endpoint_status(observed: dict[str,str], expected: dict[str,str], clean_ok: bool) -> str:
    if not clean_ok: return 'oracle_error'
    return 'matched' if observed == expected else 'stale'

def stable_latency(timeline: list[dict[str,Any]], expected: dict[str,str], edit_end_ns: int,
                   obligation: bool) -> float | None:
    """First matching sample in final uninterrupted matching suffix."""
    if not obligation or not timeline or timeline[-1]['projection'] != expected: return None
    start = len(timeline)-1
    while start > 0 and timeline[start-1]['projection'] == expected: start -= 1
    return (max(edit_end_ns,timeline[start]['t_ns'])-edit_end_ns)/1e6
